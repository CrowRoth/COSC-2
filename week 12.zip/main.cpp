#include <iostream>
#include <fstream>
#include <stack> //include stack

using namespace std;

stack <char> ree; //char stack created

int main()
{

    string line; //getline only works with strings x.x
    char c; //character for storing from reverseMe.txt

    ifstream a("reverseMe.txt"); //open and read from reverseMe.txt
    while(getline(a,line)){ // while loop to get each line
        c = line[0]; //converting first letter of string to character
        ree.push(c); //copy character to stack and push it to the top of the stack
    }
    a.close(); //close reverseMe.txt

    ofstream b("reverse.txt"); //create new file to write to

    while (!ree.empty()) { //while stack isnt empty
        b << ree.top() << endl; //write the top stack character to file
        ree.pop(); //delete top stack character
    }


    b.close(); //close new file


    return 0;
}
