#include <iostream>
#include "NumberList.h"
using namespace std;

int main(){
    // Define a new NumberList object
    NumberList list;

    int months = 0;
    double rf = 0;

    // get # of months from user
    cout << "Enter number of months: " << endl;
    cin >> months;

    // get monthly rainfall from user
    for(int i=0;i<months;i++){
        cout << "Enter the total rainfall for month " << i+1 << ": " << endl;
        cin >> rf;
        list.appendNode(rf);
    }

    list.sortAsc(); //sort in ascending order
    list.displayList();

    return 0;
}


