#pragma once
// Specification file for the NumberList class
#ifndef NUMBERLIST_H
#define NUMBERLIST_H
class NumberList
{
    // Declare a structure for the list
    struct ListNode{
        double value; // the value in the node
        struct ListNode *next;  // to point to the next node in the list
    };
    ListNode *head;  // pointer to the head of the list

    public:
    // Constructor
    NumberList(){
        head = 0; // Gaddis has this set to NULL, but NULL is undefined in this file.
    }
    // Destructor
    //~NumberList();
    // Linked list operations
    void appendNode(double);
    void insertNode(double);
    void deleteNode(double);
    void sortAsc();
    void reverse();
    void displayList() const;  // This is a constant function, it takes no arguements and returns nothing and has one purpose only.
};
#endif
