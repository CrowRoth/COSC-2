#include <iostream>
#include "NumberList.h"
using namespace std;

int main(){
    // Define a new NumberList object
    NumberList list;

    list.displayList();
    cout << endl;

    // Append some values to the list
    list.appendNode(2);
    list.appendNode(7);
    list.appendNode(12);
    list.appendNode(1);
    list.appendNode(12);
    list.appendNode(7);
    list.appendNode(8);
    list.appendNode(9);
    list.appendNode(6);
    list.appendNode(5);

    // display initial values
    list.displayList();
    cout << endl;

    // insert new item into the list
    list.insertNode(10);

    // delete 7.9 && 12.6
    list.deleteNode(7);
    list.deleteNode(12);

    // display the list
    list.displayList();
    cin.ignore();
    cin.get();

    return 0;
}


