#include <iostream>
#include "NumberList.h"
using namespace std;

void NumberList::appendNode(int num){
    ListNode *newNode; // Points to a new node in the list
    ListNode *nodePtr; // Use this to move the list

    // Allocate a new node and store num at that location
    newNode = new ListNode; // Newly created structure
    newNode->value = num; // assign num to value
    newNode->next = NULL;

    // if there are no nodes in the list
    // make newNode the first node
    if (!head){
        head = newNode;
    }
    else{ // else add new node at the end of the list
        // Initialize nodePtr to head of list
        nodePtr = head;

        // find the last node
        while (nodePtr->next){ // while there is a next to get
            nodePtr = nodePtr->next; // assign nodePtr to next
        }

        // Insert newNode as the last node
        nodePtr->next = newNode;
    }
}

void NumberList::insertNode(int num){
    ListNode *newNode; // creates new node in the list
    ListNode *nodePtr; // Used to move through the list
    ListNode *previousNode = NULL; // The node previous to the new one

    // Allocate a new node and store num in that node
    newNode = new ListNode;
    newNode->value = num;

    // If no other nodes in the list, make newNode the first node
    if (!head){
        head = newNode;
        newNode->next = NULL;
    }
    else{ // otherwise insert newNode
        //Position nodePtr at the head of the list
        nodePtr = head;

        // Initialize previousNode to NULL
        previousNode = NULL;

        // Skip all the nodes that have a value less than num
        while (nodePtr != NULL && nodePtr->value < num){
            previousNode = nodePtr;
            nodePtr = nodePtr->next;
        }

        // if the new node has a value less than the exisiting first node
        // insert at head of list
        if (previousNode == NULL){
            head = newNode;
            newNode->next = nodePtr;
        }
        else{ // insert after previousNode
            previousNode->next = newNode;
            newNode->next = nodePtr;
        }
    }// end else
}

void NumberList::displayList() const{
    ListNode *nodePtr; // used to move through the list

    // set nodePtr at head of linked list
    nodePtr = head;

    if(!head){
        cout << "List is empty." << endl;
    }

    // While nodePtr points to a node, move through the list
    while (nodePtr){
        // display the value in the current node
        cout << nodePtr->value << endl;
        // move to next node
        nodePtr = nodePtr->next;
    }
}


void NumberList::deleteNode(int num){
    ListNode *nodePtr; // to move through the list (yet again)
    ListNode *previousNode = NULL; // the node before the one we want

    // if the list is empty, do nothing
    if (!head){
        return;
    }

    // determine if the first node is the one we want to delete
    if (head->value == num){
        nodePtr = head->next;
        delete head;
        head = nodePtr;
    }
    else{ // find the value that we want to delete & delete it
        // nodePtr to head
        nodePtr = head;

        // skip all nodes with values not equal to num
        while (nodePtr != NULL && nodePtr->value != num){
            previousNode = nodePtr;
            nodePtr = nodePtr->next;
        }

        // if nodePtr is NOT at the end of list,
        // link the previous node to the one after
        // nodePtr
        if (nodePtr){
            previousNode->next = nodePtr->next;
            delete nodePtr;
        }
    }
}


