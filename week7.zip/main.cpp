#include <iostream>

using namespace std;


int doSomthing(int *x, int *y)
{
  int temp = *x;
  *x = *y * 10;
  *y = temp * 10;
  return *x + *y;
}

int main()
{
    int a,b;
    cout << "Type a number:" << endl;
    cin >> a;
    cout << "Type another number:" << endl;
    cin >> b;
    int *x = &a; //create int pointer x and target the variable a
    int *y = &b; //create int pointer y and target the variable b
    doSomthing(x,y); //send pointers to doSomthing
    cout << "Results: " << *x << " " << *y << "." << endl;
    return 0;
}
