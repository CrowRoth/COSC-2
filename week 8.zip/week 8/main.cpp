#include <iostream>

using namespace std;

double getscores(double *s);
double scoresort(double *s);
double avg(double *s,double b);
double result(double *s,double c);

int main()
{
    double scores[16];  //16 double array called scores
    double *s = scores; //pointer to scores array
    double avrg = 0;    //score average variable
    *s = getscores(s);  //setting pointer target equal to getscores with pointer s passed
    *s = scoresort(s);  //setting pointer target equal to scoresort with pointer s passed
    avrg = avg(s,avrg); //setting avrg equal to avg with pointer s passed and avrg passed
    result(s,avrg);     //passing pointer s and avrg to result
    return 0;
}

double getscores(double *s){
    bool check = false; //while loop checker
    double bleh=0;      //temporary double for checking validity
    for(int i=0;i<16;i++){  //for loop to get scores from user
        check = false;  //while loop checker reset
        cout << "Enter score for test " << i+1 << ":" << endl;
        while (!check){
            cin >> bleh;
            if (bleh < 0){
                cout << "Invalid test score!" << endl;
                cout << "Enter score for test " << i+1 << ":" << endl;
            }
            else{
                *(s+i) = bleh;  //storing valid test score into pointer target array position
                check = true;   //while loop escape to next i
            }
        }
    }
    return *s;  //return pointer target
}

double scoresort(double *s){
    double temp;    //temporary double for swapping postions
    for (int l=0; l<16; l++){   //sorting loop
        for (int i = l+1; i<16; i++){
            if (*(s+i) < *(s+l)){   //ascending order <
                temp = *(s+l);
                *(s+l) = *(s+i);
                *(s+i) = temp;
            }
        }
    }
    return *s;  //returning pointer target
}

double avg(double *s,double b){
    double total = 0;   //score total
    for (int i=0; i<16; i++){
        total += *(s+i);    //adding scores 1 at a time
    }
    b = total/16;   //averaging scores
    return b;   //returning score average
}

double result(double *s,double c){
    cout << "\nScores in ascending order:" << endl;
    for (int l=0; l<16; l++){
        cout << *(s+l) << endl; //printing out each score in pointer target array
    }
    cout << "Average: " << c << endl;  //printing out average
    return 0;
}
