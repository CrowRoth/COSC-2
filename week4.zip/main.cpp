#include <iostream>
#include <string>
using namespace std;

struct info{
    string name;
    string type; //Aircraft Carrier, Battleship, Frigate, Submarine, PT Boat)
    string sn; //Service number (USN ship service numbers contain both letters and numbers)
    int s; //(Based on the board game Battleship this is the number of pegs/hits the ship can take)
};
//function prototypes
void Menu(struct info []);
void search(struct info [],int c);
void sort(struct info []);
void show(struct info []);

int main(){
    info ship[10]; //array of structures
    //assigning variables or defining w/e
    ship[0].name = "USS George Washington";
    ship[0].type = "Aircraft Carrier";
    ship[0].sn = "CVN 73";
    ship[0].s = 5;

    ship[1].name = "USS Chicago";
    ship[1].type = "Submarine";
    ship[1].sn = "SSN 721";
    ship[1].s = 3;

    ship[2].name = "USS Nimitz";
    ship[2].type = "Aircraft Carrier";
    ship[2].sn = "CVN 68";
    ship[2].s = 5;

    ship[3].name = "USS Columbia";
    ship[3].type = "Submarine";
    ship[3].sn = "SSN 771";
    ship[3].s = 3;

    ship[4].name = "USS Cole";
    ship[4].type = "Destroyer";
    ship[4].sn = "DDG 67";
    ship[4].s = 3;

    ship[5].name = "USS Benfold";
    ship[5].type = "Destroyer";
    ship[5].sn = "DDG 65";
    ship[5].s = 3;

    ship[6].name = "USS Wyoming";
    ship[6].type = "Battleship";
    ship[6].sn = "BB 32";
    ship[6].s = 4;

    ship[7].name = "1951 PT";
    ship[7].type = "PT Boat";
    ship[7].sn = "PT 810";
    ship[7].s = 2;

    ship[8].name = "1939 PT";
    ship[8].type = "PT Boat";
    ship[8].sn = "PT 9";
    ship[8].s = 2;

    ship[9].name = "USS Washington";
    ship[9].type = "Battleship";
    ship[9].sn = "BB 47";
    ship[9].s = 4;



    Menu(ship); //initializing menu
    return 0;
}

void Menu(struct info a[]){
    int choice = 0; //users choice
    bool moist=true; //moist

    while(moist){ //loop menu until closed
        cout << "\t\tPlease choose one of the following: " << endl;
        cout << "\t**************************************************\n";
        cout << "1. Search by Name.\n\n"
             << "2. Search by Type.\n\n"
             << "3. Sort by Ship Type.\n\n"
             << "4. Display all.\n\n"
             << "5. Quit program.\n\n";
        cin >> choice; //get choice
        switch(choice){ //what happens depending on choice
            case 1: search(a,1); //sending struct array to search function
                break;
            case 2: search(a,2); //sending struct array to search function
                break;
            case 3: sort(a); //sending struct array to sort function
                break;
            case 4: show(a); //sending struct array to be printed out
                break;
            case 5:
                exit(1); //close program
                break;
            default:
                while(abs(choice) > 5){
                    cout << "\aThat was not a valid choice; Try Again.\n"; //learn to read
                cin >> choice;
                }
        }
    }


}

void search(struct info a[],int c){
    if (c==1){ //1 means to search by name
        int choice=0;
        for(int i=0;i<10;i++){ //printing out each name
            cout << i+1 << ". " << a[i].name << endl;
        }
        cout << "Choose a name (1-10): ";
        cin >> choice; // choice-1 cus arrays start at 0
        cout << a[choice-1].name << ", " << a[choice-1].type << ", " << a[choice-1].sn << ", " << a[choice-1].s << " \n";
    }
    if (c==2){ //2 means to search by type
        info temp2; //temporary info structure for sorting
        for (int l=0; l<10; l++){
            for (int j=l+1; j<10; j++){
                if (a[l].type > a[j].type){
                    temp2 = a[l];  //saving a[l]
                    a[l] = a[j];  //switching places with a[j]
                    a[j] = temp2;  //setting a[j] to what a[l] was
                }
            }
        }
        int choice=0;
        //printing out 1 type at a time
        cout << "1. " << a[0].type << endl;
        cout << "2. " << a[2].type << endl;
        cout << "3. " << a[4].type << endl;
        cout << "4. " << a[6].type << endl;
        cout << "5. " << a[8].type << endl;

        cout << "Choose a type (1-5): ";
        cin >> choice;
        switch(choice){ //switch to print out both ships of each type (2 ships per type)
            case 1:
                for(int i=0;i<2;i++){ //printing out aircraft carriers
                    cout << a[i].name << ", " << a[i].type << ", " << a[i].sn << ", " << a[i].s << " \n";
                }
                break;
            case 2:
                for(int i=2;i<4;i++){ //printing out battleships
                    cout << a[i].name << ", " << a[i].type << ", " << a[i].sn << ", " << a[i].s << " \n";
                }
                break;
            case 3:
                for(int i=4;i<6;i++){ //printing out destroyers
                    cout << a[i].name << ", " << a[i].type << ", " << a[i].sn << ", " << a[i].s << " \n";
                }
                break;
            case 4:
                for(int i=6;i<8;i++){ //printing out pt ships
                    cout << a[i].name << ", " << a[i].type << ", " << a[i].sn << ", " << a[i].s << " \n";
                }
                break;
            case 5:
                for(int i=8;i<10;i++){ //printing out submarines
                    cout << a[i].name << ", " << a[i].type << ", " << a[i].sn << ", " << a[i].s << " \n";
                }
                break;
            default:
                while(abs(choice) > 5){
                    cout << "\aThat was not a valid choice; Try Again.\n"; //learn to read
                cin >> choice;
                }
        }

    }
}

void sort(struct info a[]){
    info temp; //temporary info structure for sorting
    for (int l=0; l<10; l++){
        for (int j=l+1; j<10; j++){
            if (a[l].type > a[j].type){
                temp = a[l]; //saving a[l]
                a[l] = a[j];  //switching places with a[j]
                a[j] = temp;  //setting a[j] to what a[l] was
            }
        }
    }

    show(a);
}

void show(struct info a[]){
    for (int i = 0; i < 5; i++){
        cout << a[i].name << ", " << a[i].type << ", " << a[i].sn << ", " << a[i].s << " \n";
    }
    cin.ignore();
    cout << "press enter to continue...";
    cin.get();
    for (int i = 5; i < 10; i++){
        cout << a[i].name << ", " << a[i].type << ", " << a[i].sn << ", " << a[i].s << " \n";
    };
}


