// Focus on Problem Solving and Program design: Case Study
// Pages 529 - 534 in the Seventh Edition of the Gaddis Book
#include <iostream>
using namespace std;

// functions
void arrSelectSort(int *[], int);
void showArray(const int[], int);
void showArrPtr(int *[], int);

int main(){
    int *donations; //dynamic allocation of array

    int NUM_DONATIONS,count;

    cout << "Please enter the number of donations: ";
    cin >> NUM_DONATIONS;

    // array of donations in the order they were received
    donations = new int[NUM_DONATIONS];

    bool check; //while loop checker

    //populate the array
    cout << "Enter the donation amounts.\n";
    for (count = 0; count < NUM_DONATIONS; count++){
        cout << "Donation " << (count + 1) << ": $";
        cin >> donations[count];
        check = false; //reset to enter while loop each time
        while(!check){
            if(donations[count] >= 5){
                check = true;
            }
            else{
                cout << "Invalid donation amount.\nOnly donations of $5.00 or greater are acceptable.\n";
                count --; //go back to array position
            }
        }
    }

    // array of pointers
    int *arrPtr[NUM_DONATIONS];

    // point the pointers to the donations array
    for (int count = 0; count < NUM_DONATIONS; count++){
        arrPtr[count] = &donations[count];  // arrPtr at count is assigned the memory location of donations at count
    }

    // sort the array of pointers
    arrSelectSort(arrPtr, NUM_DONATIONS);

    // display sorted donations from arrPtr
    cout << "The donations, sorted in descending order, are: \n";
    showArrPtr(arrPtr, NUM_DONATIONS);

    // display unsorted donations in the order they were received
    cout << "\nThe donations, in their original order, are: \n";
    showArray(donations, NUM_DONATIONS);

    // Free dynamic memory
    delete[] donations;
    donations = 0; // set donations to null

    cin.ignore();
    cin.get();

    return 0;
}

// Selection sort on the array of pointers
void arrSelectSort(int *arr[], int size){
    int startScan, minIndex;
    int *minElem;
    for (startScan = 0; startScan < (size - 1); startScan++){
        minIndex = startScan;
        minElem = arr[startScan];

        for (int index = startScan + 1; index < size; index++){
            if (*(arr[index]) > *minElem){
                minElem = arr[index];
                minIndex = index;
            }
        } // end inner for loop

        arr[minIndex] = arr[startScan];
        arr[startScan] = minElem;
    } // end for loop
}

// display contents of donations[]
void showArray(const int arr[], int size){
    for (int count = 0; count < size; count++){
        cout << arr[count] << " ";
    }
    cout << endl;
}

// display contents of *arrPtr[]
void showArrPtr(int *arr[], int size){
    for (int count = 0; count < size; count++){
        cout << *(arr[count]) << " ";
    }
    cout << endl;
}
