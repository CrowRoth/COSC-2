#include <iostream>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <math.h>
#include <cstdlib>
#include <stack> //include stack

using namespace std; //cus im lazy
using namespace sf; //cus im lazy

stack<int> lives; //int stack created

float px = 200-32, py = 600-60; //player x,y coords
float mx[5] = {-200,-200,-200,-200,-200}, my[5] = {-200,-200,-200,-200,-200}; //array for 5 missles x,y coords
float ax[4] = {-100,-100,-100,-100}, ay[4] = {-100,-100,-100,-100}; //array for 4 asteroids x,y coords
int speed = 1; //player movement speed
int m = 1, mc = 1; //number of missles at the same time, current missle
bool mt[5] = {false,false,false,false,false}; //array of true false if missle is in play
bool ispressed = false, waspressed = false; //bool for delaying missle rate of fire to 1 per key press
bool at[4] = {false,false,false,false}; //array of true false if asteroid is in play
int an = 1; //asteroid random x position to spawn
float d = 0; // distance

class Missle{ //making missle sprite
public:
    Sprite shape;
    
    Missle(Texture *texture){
        this->shape.setTexture(*texture);
        this->shape.setScale(0.6f,0.6f);
    }
};

class Player{ //making player sprite
public:
    Sprite shape;
    Texture *texture;
    int HP;
    int HPMax;
    
    Player(Texture *texture){
        this->texture = texture;
        this->shape.setTexture(*texture);
        
        this->shape.setScale(0.15f,0.15f);
        this->shape.setPosition(px,py);
    }
};

class Asteroid{ //making asteroid sprites
public:
    Sprite shape;
    
    Asteroid(Texture *texture){
        this->shape.setTexture(*texture);
        this->shape.setScale(1.0f,1.0f);
    }
};

int main(){
    srand(time(NULL));
    
    for(int i=0;i<11;i++){
        lives.push(i);
    }
    cout << "Lives: " << lives.top() << endl;
    
    RenderWindow window(VideoMode(400, 600), "Space Shooter", Style::Default);
    window.setFramerateLimit(60);
    
    
    
    //init textures
    Texture shipt;
    shipt.loadFromFile("images/Spaceships/01/3.png");
    
    Texture astt[4];
    astt[0].loadFromFile("images/1.png");
    astt[1].loadFromFile("images/2.png");
    astt[2].loadFromFile("images/3.png");
    astt[3].loadFromFile("images/4.png");
    
    Texture misst;
    misst.loadFromFile("images/rocket.png");
    
    //create objects and set textures to them
    Player player(&shipt);
    Missle missle[5](&misst);
    for(int i=0;i<5;i++){
        missle[i].shape.setPosition(mx[i],my[i]);
    }
    Asteroid ast1(&astt[0]);
    Asteroid ast2(&astt[1]);
    Asteroid ast3(&astt[2]);
    Asteroid ast4(&astt[3]);
    
    for(int i=0;i<4;i++){ //set asteroid initial positions
        ast1.shape.setPosition(ax[i],ay[i]);
        ast2.shape.setPosition(ax[i],ay[i]);
        ast3.shape.setPosition(ax[i],ay[i]);
        ast4.shape.setPosition(ax[i],ay[i]);
    }
    
    while (window.isOpen()){
        Event event;
        while (window.pollEvent(event)){
            if (event.type == Event::Closed){
                window.close();
            }
        }
        
        //input
        if(Keyboard::isKeyPressed(Keyboard::Left)){ //moving player left without going past screen
            if(px > -10){
                px = px - speed;
                player.shape.setPosition(px,py);
            }
        }
        
        if(Keyboard::isKeyPressed(Keyboard::Right)){ //moving player right without going past screen
            if(px < 335){
                px = px + speed;
                player.shape.setPosition(px,py);
            }
        }
        
        if(Keyboard::isKeyPressed(Keyboard::Up)){ //moving player up without going past screen
            if(py > -18){
                py = py - speed;
                player.shape.setPosition(px,py);
            }
        }
        
        if(Keyboard::isKeyPressed(Keyboard::Down)){ //moving player down without going past screen
            if(py < 543){
                py = py + speed;
                player.shape.setPosition(px,py);
            }
        }
        
        ispressed = Keyboard::isKeyPressed(Keyboard::Space);//shooting
        if(ispressed && !waspressed){
            if(!mt[mc]){ // check if current missle is already in play
                mt[mc] = true; //put current missle into play
                mx[mc] = px + 24.5;
                my[mc] = py;
                missle[mc].shape.setPosition(mx[mc],my[mc]); //set current missle to player position
                if(mc == m-1){ //change current missle to 1 if at max number of missles
                    mc = 0;
                }else 
                if(mc < m){ //change current missle
                    mc++;
                }
            }
        }
        waspressed = ispressed;
        
        //move missles that are in play
        for(int i=0;i<5;i++){
            if(mt[i]){
                if(my[i] > -5){ //if missle has not reached end of screen move it up
                    my[i] = my[i] - 5;
                    //hit asteroid detection
                    for(int j=0;j<5;j++) { // missle number
                        for(int k=0;k<6;k++) { //how wide missle is in pixels
                            for(int l=0;l<4;l++) { //asteroid number
                                d = sqrt(pow((mx[j]+10 + k) - (ax[l]+16), 2) + pow((my[j]+5) - (ay[l]+15), 2));
                                if(d <= 15){ //hit
                                    my[j] = -200;
                                    missle[j].shape.setPosition(mx[j],my[j]);
                                    mt[j] = false;
                                    at[l] = true;
                                    an = rand()%367; //random x position for asteroid to spawn
                                    ax[l] = an;
                                    ay[l] = 0;
                                    switch(l){
                                        case 0: ast1.shape.setPosition(ax[l],ay[l]);
                                        case 1: ast2.shape.setPosition(ax[l],ay[l]);
                                        case 2: ast3.shape.setPosition(ax[l],ay[l]);
                                        case 3: ast4.shape.setPosition(ax[l],ay[l]);
                                    }
                                }
                            }
                        }
                    }
                    missle[i].shape.setPosition(mx[i],my[i]);
                }
                else{ //missle has reached end of screen, reset position and declare missle out of play
                    my[i] = -200;
                    missle[i].shape.setPosition(mx[i],my[i]);
                    mt[i] = false;
                }
            }
        }
        
        //move asteroids that are in play
        for(int i=0;i<4;i++) {
            if(at[i]){
                if(ay[i] < 570){ //if asteroid has not reached end of screen move it up
                    ay[i] = ay[i] + 2;
                    
                    for(int j=0;j<5;j++) { // asteroid number
                        for(int k=0;k<10;k++) { //how big player hitbox is in pixels
                            d = sqrt(pow((ax[j]+16) - (px+34+k), 2) + pow((ay[j]+15) - (py + 20 + k), 2));
                            if(d <= 15){ //player hit
                                lives.pop();
                                cout << "Lives: "<<lives.top() << endl;
                                cin.get();
                            }
                        }
                    }
                    
                    switch(i){
                        case 0: ast1.shape.setPosition(ax[i],ay[i]);
                        case 1: ast2.shape.setPosition(ax[i],ay[i]);
                        case 2: ast3.shape.setPosition(ax[i],ay[i]);
                        case 3: ast4.shape.setPosition(ax[i],ay[i]);
                    }
                }
                else{ //asteroid has reached end of screen, reset position and declare asteroid out of play
                    ay[i] = -100;
                    switch(i){
                        case 0: ast1.shape.setPosition(ax[i],ay[i]);
                        case 1: ast2.shape.setPosition(ax[i],ay[i]);
                        case 2: ast3.shape.setPosition(ax[i],ay[i]);
                        case 3: ast4.shape.setPosition(ax[i],ay[i]);
                    }
                    at[i] = false;
                }
            }
            else{
                at[i] = true;
                an = rand()%367; //random x position for asteroid to spawn
                ax[i] = an;
                ay[i] = 0;
                switch(i){
                    case 0: ast1.shape.setPosition(ax[i],ay[i]);
                    case 1: ast2.shape.setPosition(ax[i],ay[i]);
                    case 2: ast3.shape.setPosition(ax[i],ay[i]);
                    case 3: ast4.shape.setPosition(ax[i],ay[i]);
                }
            }
        }
        
        window.clear();
        
        
        window.draw(player.shape);
        
        for(int i=0;i<5;i++){
            window.draw(missle[i].shape);
        }
        
        window.draw(ast1.shape);
        window.draw(ast2.shape);
        window.draw(ast3.shape);
        window.draw(ast4.shape);
        
        window.display();
    }

    return 0;
}