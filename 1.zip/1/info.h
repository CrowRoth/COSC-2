#ifndef INFO_H
#define INFO_H
#include <string> //includes string commands
using namespace std; //wont have to type std anymore

class EmployeePay
{
    private:
// New and moved variables
        string name;

// Your variables
        int key; //Array ID for employee object
        const int BasePay = 15000; //Base pay set by company.
// If you set it here, make it a const int not just an int, even a private variable can be messed with.
        double payRate; //Employee's pay rate
        double pay; //Amount employee is paid per period.

    public:

        EmployeePay(); //constructor
        EmployeePay(int x); //overloaded constructor

        void setName(string e, string f){
            name = e + " " + f;
        }; //name setter to 1 string
        void setKey(int y) {
            key = y;
        }; //key setter
        void setPay(double z){
            pay = (1+z)*BasePay;
        }; //pay setter
        string getName() {
            return name;
        }; //name getter
        int getKey() {
            return key+1;
        }; //key getter
        double getPay() {
            return pay;
        }; //pay getter
};

#endif //INFO_H
