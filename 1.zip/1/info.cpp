#include <iostream>
#include "info.h"
#include <fstream>
#include <string>
using namespace std;


EmployeePay::EmployeePay()
{

}

EmployeePay::EmployeePay(int x)
{

}
