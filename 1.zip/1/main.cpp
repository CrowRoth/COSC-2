#include <iostream> //includes input/output stream commands
#include "info.h" //includes info header
#include <fstream> //includes file reading and writing commands
#include <string> //includes string commands
using namespace std; //wont have to type std anymore

int main(){

    ifstream file("employees.txt"); //reads from file

    EmployeePay emp[25]; //creating array of objects
    string fname; //first name
    string lname; // last name
    double pr; //pay rate
    int i=0; //counter

    while(file >> fname >> lname >> pr){
        emp[i].setName(fname,lname); //sending first and last name and setting to 1 string
        emp[i].setKey(i); //sending counter to set id number
        emp[i].setPay(pr); //sending payrate to calc and set pay
        i++;

    }


    for(int j=8;j<19;j++){//loops through array locations 8-18
        cout << emp[j].getKey() << " " << emp[j].getName() << " " << emp[j].getPay() << endl; //gets objects variables and prints them out
    }


    file.close(); //gotta close file
    return 0;
}
