#include <iostream>
using namespace std;

// functions
double mean(int *[], int);
int median(int *[], int);
int mode(int *[], int,int *[]);
void show(int arr[], int size, double a, int b, int c, int d[]);

int main(){
    int *movies; //dynamic allocation of array
    int *mods; //dynamic allocation of array
    int students,count;

    cout << "Please enter the number of students: ";
    cin >> students;

    // array of donations in the order they were received
    movies = new int[students];

    mods = new int[students]; //array of modes

    bool check; //while loop checker

    //populate the array
    cout << "Enter the number of movies watched in a month.\n";
    for (count = 0; count < students; count++){
        cout << "Student " << (count + 1) << ": ";
        cin >> movies[count];
        check = false; //reset to enter while loop each time
        while(!check){
            if(movies[count] >= 1){
                check = true;
            }
            else{
                cout << "Invalid movie amount.\n";
                count --; //go back to array position
            }
        }
    }

    // array of pointers
    int *arrPtr[students];
    int *m[students];

    // point the pointers to the movies and modes array
    for (int count = 0; count < students; count++){
        arrPtr[count] = &movies[count];  // arrPtr at count is assigned the memory location of movies at count
        m[count] = &mods[count];
    }

    int med,mod; //median, and # of modes
    double mea; //mean

    // find the mean movies
    mea = mean(arrPtr, students);

    // find the median movies
    med = median(arrPtr, students);

    // find the mode movies
    mod = mode(arrPtr, students, m);

    show(movies, students, mea, med, mod, mods);

    // Free dynamic memory
    delete[] movies,mods;
    movies, mods = 0; // set movies and modes to null

    cin.ignore();
    cin.get();

    return 0;
}

double mean(int *arr[], int size){
    int total = 0; //total amount of movies watched
    for(int i=0;i<size;i++){
        total += *arr[i];
    }
    double mea = (double) total/size; //average
    return mea;
}

int median(int *arr[], int size){
    int temp;    //temporary for swapping positions
    for (int l=0; l<size; l++){   //sorting loop
        for (int i = l+1; i<size; i++){
            if (*arr[i] < *arr[l]){   //ascending order <
                temp = *arr[l];
                *arr[l] = *arr[i];
                *arr[i] = temp;
            }
        }
    }

    int pos = size/2; //int value of middle position ex. 3.5 = 3
    double rem = size % 2; //remainder of pos

    if(rem == .5){
        pos++; //rounding pos up if size is odd
    }

    int med = *arr[pos];
    return med;
}

int mode(int *arr[], int size, int *m[]){
    int copies[size]; //counts how many movies watched are the same number

    for(int i=0;i<size;i++){ //sets copies and pointer m to 0
        copies[i] =0;
        *m[i] =0;
    }

    // count how many times numbers occur
    for(int i=0; i < size; i++){
        for(int j=i+1; j < size; j++){
            if(*(arr[i]) == *(arr[j])){
                copies[i]++;
            }
        }
    }

    int save[size]; //save positions of copies
    for(int i=0; i < size; i++){
        save[i] = copies[i];
    }

    int temp;    //temporary for swapping positions
    for (int l=0; l<size; l++){   //sorting loop
        for (int i = l+1; i<size; i++){
            if (copies[i] > copies[l]){   //descending order >
                temp = copies[l];
                copies[l] = copies[i];
                copies[i] = temp;
            }
        }
    }

    int c = 0; //#of modes
    if(copies[0] == 0){ //if biggest mode has 0 copies return 0
        return c;
    }else if(copies[0] == copies[1]){ //if biggest mode is same size as 2nd, it means theres more than 1 mode
        for (int i=0; i<size; i++){
            if(save[i] == copies[0]){ // finding positions in save[] of modes
                 *m[c] = i; //saving positions of modes
                 c++; //counting number of modes
            }
        }

        for(int i=0;i<c;i++){
            *m[i] = *arr[*m[i]]; //saving values of modes using previously stored positions of modes
        }

        return c;
    }else{
        for(int b=0; b < size; b++){
            if(save[b] == copies[0]){
                *m[0] = b; //saving position of mode
            }
        }
        *m[0] = *arr[*m[0]]; //saving value of mode using previously stored position
        c = 1;
        return c;
    }


}

void show(int arr[], int size, double a, int b, int c, int d[]){
    cout << "# of students: " << size << "\nMean: " << a << "\nMedian: " << b << "\nMode: ";
    if(c == 0){ //if no modes n/a
        cout << "n/a";
    }
    else if(c == 1){ // if 1 mode output it
        cout << d[0];
    }
    else{ //if multiple modes output first one
        cout << d[0];
        for(int i=1;i<c;i++){ //then for loop to c(#of modes) displaying , mode2, mode3, etc.
            cout << ", " << d[i];
        }
    }
}

