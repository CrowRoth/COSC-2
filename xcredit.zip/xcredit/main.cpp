#include <iostream>
#include <stdlib.h>
#include <random>

using namespace std;

extern "C" char* n(int lvl ) ;
extern "C" int hitpoints(int x ) ;
extern "C" int damage(int y ) ;



int main()
{
    int dir;
    cout << "Welcome to The Castle" << endl;
    cout << "-\\-\\-\\-\\-\\-\\-\\-\\-\\-\\-" << endl;
    cout << "Level 1" << endl;

    bool done=false;

    while(!done){
        cout << "Choose a way to go: up(1),down(2),left(3),right(4):" << endl;
        cin >> dir;

        switch (dir){
            case 1:
                cout << "A monster appeared." << endl;
                done=true;
                break;
            case 2:
                cout << "The door is locked shut, the only way is forward." << endl;
                break;
            case 3:
                cout << "Theres a wall blocking the way." << endl;
                break;
            case 4:
                cout << "Theres a wall blocking the way." << endl;
                break;
            default:
                cout << "Not a valid direction" << endl;
                break;
        }

    }

    int a = rand() % 3 + 1;
    char* name = n(a);
    int hp = hitpoints(a);
    int dmg = damage(a);

    bool dead = false;
    int act;
    int hit = 0;
    int att = 0;
    int run = 0;

    while(!dead) {
        cout << "What will you do? (1) to attack (2) to run." << endl;
        cout << "Monster: " << name << endl;
        cout << "HitPoints: " << hp << endl;
        cin >> act;

        switch (act){
        case 1:
            hit = rand() % 3 + 1;
            if(hit > 1){
                att = rand() % 5 + 1;
                cout << "You hit the " << name << " for " << att << " damage!" << endl;
                hp = hp - att;
            }
            else{
                cout << "You missed!" << endl;
            }
            if(hp <= 0){
                cout << "You slayed the " << name << "." << endl;
                dead = true;
            }
            break;
        case 2:
            run = rand() % 100 + 1;
            if(run > 90){
                cout << "You escaped!" << endl;
                dead = true;
                break;
            }
            else{
                cout << "Could not escape." << endl;
            }
            break;
        default:
            cout << "Not a valid action" << endl;
            break;
        }

    }

    cout << "gratz u r 2 stronk. The end." << endl;


}
