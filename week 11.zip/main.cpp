#include <iostream>
#include "NumberList.h"
using namespace std;

int main(){
    // Define a new NumberList object
    NumberList list;

    list.displayList();
    cout << endl;

    // Append some values to the list
    list.appendNode(1);
    list.appendNode(2);
    list.appendNode(3);

    // display initial values
    list.displayList();
    cout << endl;

    list.reverse();
    list.displayList();
    cout << endl;

    // insert new item into the list
    list.insertNode(10);

    // delete 1
    list.deleteNode(1);

    // display the list
    list.displayList();
    cin.ignore();
    cin.get();

    return 0;
}


