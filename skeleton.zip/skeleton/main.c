struct monster{
    char* name;
    int hp;
    int dmg;
};

struct monster skeleton;
struct monster ghoul;
struct monster ww;

char* n(int lvl){
    switch (lvl){
    case 1:;
        skeleton.name = "Skeleton";
        return skeleton.name;
        break;
    case 2:;
        ghoul.name = "Ghoul";
        return ghoul.name;
        break;
    case 3:;
        ww.name = "Werewolf";
        return ww.name;
        break;
    }
}

int hitpoints(int x){
    switch (x){
    case 1:;
        skeleton.hp = 10;
        return skeleton.hp;
        break;
    case 2:;
        ghoul.hp = 15;
        return ghoul.hp;
        break;
    case 3:;
        ww.hp = 20;
        return ww.hp;
        break;
    }
}

int damage(int y){
    switch (y){
    case 1:;
        skeleton.dmg = 1;
        return skeleton.dmg;
        break;
    case 2:;
        ghoul.dmg = 2;
        return ghoul.dmg;
        break;
    case 3:;
        ww.dmg = 3;
        return ww.dmg;
        break;
    }
}
