#include <iostream>
#include <string>

using namespace std;

struct movie {  //stucture
    string title;   //Title
    string director;    //Director
    int year;   //Year Released
    int time;   //Running Time (in minutes)
    long int cost;    //Production Costs
    long int profit;  //Profits
};

void printout (movie& x){ //converting movie structures to smaller variable
    cout << "Title: "<< x.title << endl; //printing out each variable of structures sent
    cout << "Director(s): "<< x.director << endl;
    cout << "Year Released: "<< x.year << endl;
    cout << "Run Time: "<< x.time << endl;
    cout << "Production Costs: $" << x.cost << endl;
    cout << "Profits: $" << x.profit << endl << endl;
}

void init(){
    movie starwars, alladin; //making struct instances

    starwars.title = "Star Wars";  //assigning starwars movie info
    starwars.director = "George Lucas";
    starwars.year = 1977;
    starwars.time = 121;
    starwars.cost = 11000000;
    starwars.profit = 775800000 - starwars.cost;

    alladin.title = "Alladin";  //assigning alladin movie info
    alladin.director = "John Musker & Ron Clements";
    alladin.year = 1992;
    alladin.time = 90;
    alladin.cost = 28000000;
    alladin.profit = 504100000 - alladin.cost;

    printout(starwars); //sending starwars structure to be printed out
    printout(alladin); //sending alladins structure to be printed out
}

int main()
{
    init(); //call init

    return 0;
}
